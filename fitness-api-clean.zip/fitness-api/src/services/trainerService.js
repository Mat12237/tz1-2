const trainerRepo = require('../repositories/trainerRepository');

const VALID_STATUSES = ['WORKING', 'ON_LEAVE', 'NOT_WORKING'];

class TrainerService {
  getAll() {
    return trainerRepo.findAll();
  }

  getById(id) {
    const trainer = trainerRepo.findById(id);
    if (!trainer) {
      const err = new Error('Тренер не найден');
      err.status = 404;
      throw err;
    }
    return trainer;
  }

  getDetail(id) {
    const trainer = this.getById(id);
    const clients = trainerRepo.getClients(id);
    return { ...trainer, clients };
  }

  create(data) {
    return trainerRepo.create(data);
  }

  update(id, data) {
    this.getById(id);
    return trainerRepo.update(id, data);
  }

  updateStatus(id, status) {
    if (!VALID_STATUSES.includes(status)) {
      const err = new Error(`Недопустимый статус. Допустимые значения: ${VALID_STATUSES.join(', ')}`);
      err.status = 400;
      throw err;
    }
    this.getById(id);
    return trainerRepo.updateStatus(id, status);
  }
}

module.exports = new TrainerService();
