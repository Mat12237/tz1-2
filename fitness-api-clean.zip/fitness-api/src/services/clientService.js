const clientRepo = require('../repositories/clientRepository');
const trainerRepo = require('../repositories/trainerRepository');

class ClientService {
  getAll() {
    return clientRepo.findAll();
  }

  getById(id) {
    const client = clientRepo.findById(id);
    if (!client) {
      const err = new Error('Клиент не найден');
      err.status = 404;
      throw err;
    }
    return client;
  }

  getDetail(id) {
    const client = this.getById(id);
    let trainer = null;
    if (client.trainer_id) {
      trainer = trainerRepo.findById(client.trainer_id) || null;
    }
    const { trainer_id, ...rest } = client;
    return { ...rest, trainer };
  }

  create(data) {
    if (data.trainer_id) {
      const trainer = trainerRepo.findById(data.trainer_id);
      if (!trainer) {
        const err = new Error('Тренер с указанным trainer_id не найден');
        err.status = 404;
        throw err;
      }
    }
    return clientRepo.create(data);
  }

  update(id, data) {
    this.getById(id);
    return clientRepo.update(id, data);
  }

  updateStatus(id, is_active) {
    if (typeof is_active !== 'boolean') {
      const err = new Error('Поле is_active должно быть булевым значением (true/false)');
      err.status = 400;
      throw err;
    }
    this.getById(id);
    return clientRepo.updateStatus(id, is_active);
  }

  assignTrainer(clientId, trainerId) {
    this.getById(clientId);
    const trainer = trainerRepo.findById(trainerId);
    if (!trainer) {
      const err = new Error('Тренер не найден');
      err.status = 404;
      throw err;
    }
    return clientRepo.assignTrainer(clientId, trainerId);
  }
}

module.exports = new ClientService();
