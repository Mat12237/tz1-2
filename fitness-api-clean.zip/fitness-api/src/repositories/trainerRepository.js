const { v4: uuidv4 } = require('uuid');
const store = require('../models/store');

class TrainerRepository {
  findAll() {
    return Array.from(store.trainers.values());
  }

  findById(id) {
    return store.trainers.get(id) || null;
  }

  create(data) {
    const trainer = {
      id: uuidv4(),
      surname: data.surname,
      name: data.name,
      patronymic: data.patronymic ?? null,
      phone: data.phone,
      status: data.status ?? 'WORKING',
    };
    store.trainers.set(trainer.id, trainer);
    return trainer;
  }

  update(id, data) {
    const trainer = store.trainers.get(id);
    if (!trainer) return null;
    const updated = {
      ...trainer,
      surname: data.surname ?? trainer.surname,
      name: data.name ?? trainer.name,
      patronymic: data.patronymic !== undefined ? data.patronymic : trainer.patronymic,
      phone: data.phone ?? trainer.phone,
    };
    store.trainers.set(id, updated);
    return updated;
  }

  updateStatus(id, status) {
    const trainer = store.trainers.get(id);
    if (!trainer) return null;
    const updated = { ...trainer, status };
    store.trainers.set(id, updated);
    return updated;
  }

  getClients(trainerId) {
    return Array.from(store.clients.values()).filter(
      (c) => c.trainer_id === trainerId,
    );
  }
}

module.exports = new TrainerRepository();
