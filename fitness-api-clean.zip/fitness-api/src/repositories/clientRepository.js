const { v4: uuidv4 } = require('uuid');
const store = require('../models/store');

class ClientRepository {
  findAll() {
    return Array.from(store.clients.values());
  }

  findById(id) {
    return store.clients.get(id) || null;
  }

  create(data) {
    const client = {
      id: uuidv4(),
      surname: data.surname,
      name: data.name,
      patronymic: data.patronymic ?? null,
      birthday: data.birthday,
      phone: data.phone,
      email: data.email,
      is_active: data.is_active !== undefined ? data.is_active : true,
      trainer_id: data.trainer_id ?? null,
    };
    store.clients.set(client.id, client);
    return client;
  }

  update(id, data) {
    const client = store.clients.get(id);
    if (!client) return null;
    const updated = {
      ...client,
      surname: data.surname ?? client.surname,
      name: data.name ?? client.name,
      patronymic: data.patronymic !== undefined ? data.patronymic : client.patronymic,
      birthday: data.birthday ?? client.birthday,
      phone: data.phone ?? client.phone,
      email: data.email ?? client.email,
    };
    store.clients.set(id, updated);
    return updated;
  }

  updateStatus(id, is_active) {
    const client = store.clients.get(id);
    if (!client) return null;
    const updated = { ...client, is_active };
    store.clients.set(id, updated);
    return updated;
  }

  assignTrainer(clientId, trainerId) {
    const client = store.clients.get(clientId);
    if (!client) return null;
    const updated = { ...client, trainer_id: trainerId };
    store.clients.set(clientId, updated);
    return updated;
  }
}

module.exports = new ClientRepository();
