const { v4: uuidv4 } = require('uuid');

const store = {
  clients: new Map(),
  trainers: new Map(),
};

const t1 = uuidv4();
const t2 = uuidv4();

store.trainers.set(t1, {
  id: t1,
  surname: 'Смирнов',
  name: 'Алексей',
  patronymic: 'Игоревич',
  phone: '+79001112233',
  status: 'WORKING',
});

store.trainers.set(t2, {
  id: t2,
  surname: 'Козлова',
  name: 'Марина',
  patronymic: null,
  phone: '+79009998877',
  status: 'ON_LEAVE',
});

const c1 = uuidv4();
store.clients.set(c1, {
  id: c1,
  surname: 'Иванов',
  name: 'Иван',
  patronymic: 'Иванович',
  birthday: '1990-05-15',
  phone: '+79111234567',
  email: 'ivan@example.com',
  is_active: true,
  trainer_id: t1,
});

module.exports = store;
