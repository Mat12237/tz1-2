const clientService = require('../services/clientService');

const getAll = (req, res, next) => {
  try {
    res.json(clientService.getAll());
  } catch (err) {
    next(err);
  }
};

const getById = (req, res, next) => {
  try {
    res.json(clientService.getById(req.params.id));
  } catch (err) {
    next(err);
  }
};

const getDetail = (req, res, next) => {
  try {
    res.json(clientService.getDetail(req.params.id));
  } catch (err) {
    next(err);
  }
};

const create = (req, res, next) => {
  try {
    const client = clientService.create(req.body);
    res.status(201).json(client);
  } catch (err) {
    next(err);
  }
};

const update = (req, res, next) => {
  try {
    const client = clientService.update(req.params.id, req.body);
    res.json(client);
  } catch (err) {
    next(err);
  }
};

const updateStatus = (req, res, next) => {
  try {
    const client = clientService.updateStatus(req.params.id, req.body.is_active);
    res.json(client);
  } catch (err) {
    next(err);
  }
};

const assignTrainer = (req, res, next) => {
  try {
    const client = clientService.assignTrainer(
      req.params.clientId,
      req.params.trainerId,
    );
    res.json(client);
  } catch (err) {
    next(err);
  }
};

module.exports = { getAll, getById, getDetail, create, update, updateStatus, assignTrainer };
