const trainerService = require('../services/trainerService');

const getAll = (req, res, next) => {
  try {
    res.json(trainerService.getAll());
  } catch (err) {
    next(err);
  }
};

const getDetail = (req, res, next) => {
  try {
    res.json(trainerService.getDetail(req.params.id));
  } catch (err) {
    next(err);
  }
};

const create = (req, res, next) => {
  try {
    const trainer = trainerService.create(req.body);
    res.status(201).json(trainer);
  } catch (err) {
    next(err);
  }
};

const update = (req, res, next) => {
  try {
    const trainer = trainerService.update(req.params.id, req.body);
    res.json(trainer);
  } catch (err) {
    next(err);
  }
};

const updateStatus = (req, res, next) => {
  try {
    const trainer = trainerService.updateStatus(req.params.id, req.body.status);
    res.json(trainer);
  } catch (err) {
    next(err);
  }
};

module.exports = { getAll, getDetail, create, update, updateStatus };
