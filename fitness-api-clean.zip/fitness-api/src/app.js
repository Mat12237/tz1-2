const express = require('express');
const path = require('path');
const app = express();

app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

const clientRoutes = require('./routes/clients');
const trainerRoutes = require('./routes/trainers');

app.use('/api/clients', clientRoutes);
app.use('/api/trainers', trainerRoutes);

app.use('/api', (req, res) => {
  res.status(404).json({ error: `Маршрут ${req.method} ${req.path} не найден` });
});

const errorHandler = require('./middleware/errorHandler');
app.use(errorHandler);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Сервер запущен: http://localhost:${PORT}`);
});

module.exports = app;
